# Anonymous reproduction package

This archive reproduces the score-based tables and figures from committed
compact aggregates:

```bash
uv sync --frozen
uv run python scripts/prepare_climatology_figure_data.py
EXTREMES_VARIANT=_climatology uv run python scripts/make_numbers.py
EXTREMES_VARIANT=_climatology uv run python scripts/write_paper_tables.py
EXTREMES_VARIANT=_climatology uv run python scripts/figures_v4.py
EXTREMES_VARIANT=_climatology uv run python scripts/fig_tail_penalty.py
uv run python scripts/fig_conditional_bias.py
```

Rebuilding the aggregates requires warehouse-derived bucketed metric inputs
that are not included. Station identities, station coordinates, and the full
threshold parquet are withheld, so the static station map and station-count
table are supplied only in the separate manuscript source package.
