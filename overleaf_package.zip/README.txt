OVERLEAF UPLOAD PACKAGE

1. Upload this zip as a new Overleaf project.
2. Set main.tex as the Main document if Overleaf does not detect it.
3. Compiler: pdfLaTeX (Overleaf default). The repository's local verification
   build uses the pinned Tectonic 0.16.9 engine.
4. Bibliography: references.bib; BibTeX runs automatically.

The figures and table fragments are generated artifacts included in this
anonymous supplementary package.
