OVERLEAF UPLOAD PACKAGE

1. Upload this zip as a new Overleaf project.
2. Set main.tex as the Main document if Overleaf does not detect it.
3. Compiler: pdfLaTeX (Overleaf default).
4. Bibliography: references.bib; BibTeX runs automatically.

NOT FOR REVIEWER UPLOAD: main.tex contains the camera-ready author block.
Use supplementary_material.zip (scripts/package_supplement.py) instead.
